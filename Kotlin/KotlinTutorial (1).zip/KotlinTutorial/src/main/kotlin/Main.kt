fun main(args: Array<String>) {
    print("Hola mundo!")
}